import requests
import json

url = "http://localhost:5000" 
data = {
    "jsonrpc": "2.0",
    "method": "add",
    "params": [1, 2],  
    "id": 1
}

response = requests.post(url, json=data)

print(response.json())
