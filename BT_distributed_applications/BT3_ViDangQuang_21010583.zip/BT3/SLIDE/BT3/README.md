# JSON-RPC Example

## Cài đặt
1. Cài đặt thư viện Python:
'''
    pip install -r requirements.txt
'''