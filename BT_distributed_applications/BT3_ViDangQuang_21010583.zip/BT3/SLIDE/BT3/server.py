from jsonrpcserver import method, serve

@method
def add(a, b):
    return a + b

if __name__ == "__main__":
    print("Server is running...")
    serve()  
