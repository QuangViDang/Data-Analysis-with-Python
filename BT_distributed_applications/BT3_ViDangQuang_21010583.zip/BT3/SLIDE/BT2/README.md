# RabbitMQ System Example

## Cài đặt
1. Cài đặt RabbitMQ: https://www.rabbitmq.com/download.html
2. Cài đặt thư viện Python: 
'''
    pip install -r requirements.txt
'''