#include <stdio.h>
#include "myrpc.h"

void MyProcedure(char* input, char** output)
{
    *output = "Hello from server!";
}

int main()
{
    RPC_STATUS status;
    
    status = RpcServerUseProtseqEp("ncacn_ip_tcp", RPC_C_PROTSEQ_MAX_REQS_DEFAULT, "4747", NULL);
    if (status) {
        printf("RpcServerUseProtseqEp failed with error %d\n", status);
        return 1;
    }

    status = RpcServerRegisterIf(MyRpcInterface_v1_0_s_ifspec, NULL, NULL);
    if (status) {
        printf("RpcServerRegisterIf failed with error %d\n", status);
        return 1;
    }

    printf("Server is running...\n");

    RpcServerListen(1, RPC_C_LISTEN_MAX_CALLS_DEFAULT, 0);

    return 0;
}
