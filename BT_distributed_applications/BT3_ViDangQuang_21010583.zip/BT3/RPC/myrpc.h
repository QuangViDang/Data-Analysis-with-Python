#ifndef MYRPC_H
#define MYRPC_H

#include <rpc.h>

extern RPC_IF_HANDLE MyRpcInterface_v1_0_c_ifspec;
extern RPC_IF_HANDLE MyRpcInterface_v1_0_s_ifspec;

void MyProcedure(char* input, char** output);

#endif