#include <stdio.h>
#include "myrpc.h"

int main()
{
    RPC_STATUS status;
    char* input = "Client request";
    char* output;
    RPC_BINDING_HANDLE binding_handle;

    status = RpcBindingFromStringBinding("ncacn_ip_tcp:4747", &binding_handle);
    if (status) {
        printf("RpcBindingFromStringBinding failed with error %d\n", status);
        return 1;
    }

    status = MyProcedure(binding_handle, input, &output);
    if (status) {
        printf("MyProcedure failed with error %d\n", status);
        return 1;
    }

    printf("Server response: %s\n", output);

    return 0;
}
